myRFMpackage
--------

"myRFMpackage" provides basic functionality for working with customer data. 

Further description...

