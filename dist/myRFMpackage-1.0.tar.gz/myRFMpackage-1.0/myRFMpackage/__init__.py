#!/usr/bin/env python3

#!/usr/bin/env python3
"""
#########################################################################################
Copyright (c) 2016. All rights reserved.  See the file LICENSE for
license terms.
#########################################################################################

File: LE_Packages.py
Proj: Python Workshop
Desc: A non-technical introduction to Python, 
Auth: Sylvia Schumacher
Date: 2017/12/01
"""
#%%
"""
####################################################################
Exercise 1: Create your first package
####################################################################
"""
#%%
from .calculateRFM import calculateRFM
#%%